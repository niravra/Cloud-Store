# csye6225-fall2017
NetWork Structures and Cloud Computing
=======
# Team Members #
* Ashwini Thaokar (thaokar.a@husky.neu.edu)
* Niravra Kar (kar.n@husky.neu.edu)
* Parakh Mahajan (mahajan.p@husky.neu.edu)
* Sumedh Saraf (saraf.s@husky.neu.edu)
# Scripts to launch ec2 instances in aws #
